# BES2800BP 固件编译、烧录与测试参考

源自《BES2800BP 代码下载·烧录·测试完整操作指南》（HTML→MD 版在 `D:\BES2800BP\BES2800BP_代码下载烧录测试指南.md`）。

## 1. 整体流程

硬件准备 → 代码下载编译 → 固件传输（Linux→Windows SCP）→ dldtool 烧录 → 测试验证

**最高警告：EVB 串口通信电平 1.8V**，下载口和 Log 口都一样，接错电平烧 GPIO。

## 2. 编译（Linux 服务器）

```bash
git clone <open-vela-repo> open-vela && cd open-vela
cp vendor/bes/readme/1700_ap.sh ./
./1700_ap.sh        # 产物在 cmake_out/aos_evb_ap/ 等目录
```

## 3. 固件文件说明

| 固件 | 大小 | 说明 |
|---|---|---|
| `nuttx_ap.bin` | 1.7 MB | **AP 核心**（主应用处理器 NuttX 镜像） |
| `nuttx_apc1.bin` | 1.9 MB | APC1 协处理器 |
| `nuttx_apns.bin` | 8.4 MB | AP NS（Non-Secure） |
| `nuttx_bl.bin` | 125 KB | Bootloader |
| `nuttx_ota.bin` | 646 KB | OTA 空中升级 |
| `nuttx_bth.bin` | 879 KB | 蓝牙主镜像 |
| `nuttx_bthcp.bin` | 375 KB | 蓝牙 CP |
| `nuttx_hifi.bin` | 1.5 MB | HiFi 音频 DSP |
| `nuttx_tee.bin` | 1.3 MB | TEE 安全环境 |
| `programmer1700_dual.bin` | 69 KB | **编程器固件**（下载引导，双芯片模式） |

## 4. 固件传输（SCP，Windows PowerShell 执行）

```bash
scp hma@192.168.12.26:~/open-vela/vela-opensource/cmake_out/aos_evb_ap/nuttx_ap.bin D:\BES2800BP\program\
```

- 批量下载+烧录用 `fwcp.bat`（内置服务器 `bes@10.21.220.143`，还会拉 `nuttx_ap.elf` 到 `C:\Users\Administrator\Downloads\jtag-elf` 供 JTAG）。
- 反向传输：`libs_sync.bat`（本地 .a → 服务器 ~/bugs/libs/）、`log_scp.bat`（log → ~/bugs/）。
- **所有服务器 IP、用户名、路径、COM 口号都是硬编码，使用前必须按实际环境改。**

## 5. 烧录（dldtool.exe）

前置：`dldtool.exe` + `programmer1700_dual.bin` + 全部 .bin 放同一目录（`D:\BES2800BP\program\`）；设备管理器确认 COM 口；`cd D:\BES2800BP\program`。

### 全量烧录（首次/恢复出厂）

```bat
.\dldtool.exe 3 --reboot .\programmer1700_dual.bin ^
    -M .\nuttx_bl.bin  ^
    --set-dual-chip 1 -M .\nuttx_ota.bin  ^
    -M .\nuttx_ap.bin ^
    -M .\nuttx_apc1.bin ^
    -M .\nuttx_bth.bin ^
    -M .\nuttx_bthcp.bin ^
    --addr 0x30D90000 .\nuttx_hifi.bin --pgm-rate 2000000
```

| 参数 | 说明 |
|---|---|
| `3`（首参） | COM 口编号，按实际改（见过 3/15/21/41/74） |
| `--reboot` | 烧完自动重启 |
| `--set-dual-chip 1` | 双芯片模式 |
| `-M <file>` | 指定烧录固件（可多个） |
| `--addr 0x30D90000` | HiFi 固件烧录地址 |
| `--pgm-rate 2000000` | 编程速率 2MHz |

### 仅刷 AP（日常开发）

```bat
.\dldtool.exe 74 --reboot .\programmer1700_dual.bin ^
    --set-dual-chip 1 -M .\nuttx_ap.bin --pgm-rate 2000000
```

apc1/ota 单刷同理，只换 `-M` 的固件。

### 烧录操作时序（易错）

1. 执行命令；
2. 终端显示 **`Wait for SYNC started`** 时**再按 EVB 的 RESET**（按早会同步失败）；
3. 显示 **`PROGRAMMING SUCCEEDED`** = 成功；
4. 按 POWER 重启。

## 6. 脚本速查表

| 脚本 | COM | 功能 |
|---|---|---|
| `updateall.bat` | 3 | 全量烧录 7 个固件 |
| `ap_update.bat` | 74 | SCP 拉取 + 仅刷 AP |
| `apc1_update.bat` | 3 | SCP 拉取 + 仅刷 APC1 |
| `ota_update.bat` | 41 | SCP 拉取 + 仅刷 OTA |
| `fwcp.bat` | 21 | 批量下载全部固件+ELF，再全量烧录 |
| `libs_sync.bat` | — | 上传 .a 库到服务器 |
| `log_scp.bat` | — | 上传串口 log 到服务器 |

## 7. 测试验证

1. **Log 查看**：串口调试器接 **P54(UART1 TX)/P55(UART1 RX)**（1.8V！），PuTTY/MobaXterm，波特率 115200 或 921600；启动后可进 NuttX Shell 交互。
2. **功能测试**：屏幕（烧 vela 测试 bin 看 RM69330 显示）、触摸（TMA525）、WiFi（`ifconfig`/`wapi`）、蓝牙（`bt` 命令）、音频（HiFi log）、EMMC（`ls /mnt`）、NOR Flash。
3. **传感器**：`i2c scan` → `uorb_listener sensor_accel`（详见 bmi270-integration.md）。
4. **下载口 vs Log 口别接错**：Type-C（USB2 Uart）= 下载；P54/P55 = Log。

## 8. 常见问题

1. 串口电平必须 1.8V（最重要，重复三遍都不多）。
2. COM 口号每次用前在设备管理器确认并改脚本。
3. 服务器 IP/路径按实际编译环境改。
4. 看到 SYNC 提示再按 RESET。
5. 首次烧录用 updateall 保证各固件版本一致，日常只刷 AP。
