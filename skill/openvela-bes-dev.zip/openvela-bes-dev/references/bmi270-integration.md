# BMI270 六轴传感器接入 BES2800BP 完整参考

涵盖接线、地址、驱动、上电初始化、跌倒检测算法、标定验证。完整 10 章方案见工作区 `BMI270_BES2800BP_接入方案.md`（若可用）。

## 1. 关键参数速查

| 项目 | 参数 |
|---|---|
| CHIP_ID | **0x24**（寄存器 0x00；BMI160 是 0xD1，勿混） |
| 通道 | 16-bit 三轴加速度 + 16-bit 三轴陀螺 |
| 加速度量程 | ±2/±4/±8/±16 g（跌倒检测用 **±16g** 防饱和） |
| 陀螺量程 | ±125~±2000 °/s（跌倒检测用 ±2000） |
| ODR | accel 最高 1600 Hz / gyro 最高 3200 Hz（跌倒检测用 200 Hz） |
| FIFO | 约 6 KB，支持 header/水印中断 |
| I2C 地址 | **0x68（SDO=GND）/ 0x69（SDO=VDDIO）** |
| 封装 | LGA-14，2.5×3.0×0.83 mm |
| 内置 feature | 计步/活动识别/显著运动/抬腕唤醒/倾斜/高低 g |
| 辅助口 | 可挂 BMM150 地磁扩 9 轴 |

## 2. 接线与地址

实战接法（6 针模块 + EVB）：

| BMI270 | 接 EVB | 说明 |
|---|---|---|
| SCL | G36 (I2C1_SCL) | IOMUX 复用，可换 |
| SDA | G37 (I2C1_SDA) | 与 SCL 相邻 |
| INT1 | G40 | 支持外部中断/唤醒的 GPIO，优先 always-on 域 |
| VCC | VSYS 插针 3.3V | |
| GND | GND | 电源地，必接 |
| SDO | GND → 地址 0x68 | **地址选择脚，不是电源脚**；接 VDDIO 则 0x69 |

**GND 与 SDO→GND 的区别**：GND 是电源回路（必接）；SDO 是逻辑电平配置脚，借 GND 当低电平来选定 I2C 地址 0x68。二者物理上可接同一 GND 网络，作用完全不同。8-bit 写法 0xD0(写)/0xD1(读) = 0x68 左移 1 位，同一地址。

**6 针模块的两个隐患**（无 SDO/CSB 引脚时）：
1. 地址由模块内部电阻固定（多数下拉 SDO → 0x68），上电先 `i2c scan` 确认；若与板载器件撞 0x68 且无法改，只能换另一条 I2C 总线。
2. **必须确认 CSB 已在模块内部上拉到 VDDIO**，否则芯片停在 SPI 模式。验证：扫不到时断电量模块背面 CSB 焊盘与 3.3V 是否导通，不通则飞线补上。

## 3. 驱动：NuttX 主线现成

```
drivers/sensors/
├── bmi270_base.c   # 寄存器层 + 8KB 配置文件 g_bmi270_config_file
├── bmi270.c        # 字符设备模式
├── bmi270_uorb.c   # uORB 模式 ★推荐
└── Kconfig         # SENSORS_BMI270 / _UORB / _I2C / _SPI / LOAD_FROM_HEAP
```

menuconfig 要点：
- `CONFIG_SENSORS_BMI270=y`、`CONFIG_SENSORS_BMI270_UORB=y`、`CONFIG_SENSORS_BMI270_I2C=y`
- 不勾选 polling（用中断+FIFO）
- **`CONFIG_SENSORS_BMI270_LOAD_FROM_HEAP`**：平台 flash 不支持 DMA 直传时必须开，否则配置上传失败——表现为 CHIP_ID 读得到但 `INTERNAL_STATUS` 报 init_err，高级功能全哑。
- OpenVela 版本偏旧无 `bmi270_uorb.c` 时：从 apache/nuttx 主线 backport 三个文件，或用 Bosch 官方 BMI270_SensorAPI 自包 uORB。

Board 侧注册（要点）：`i2c_initialize(bus)` → 配 INT1 GPIO 中断/唤醒 → `bmi270_register_uorb(0, i2c, NULL)` → 生成 `/dev/uorb/sensor_accel0` 等节点。地址宏与硬件 SDO 电平一致。

## 4. 上电初始化时序（自写/调驱动时必看）

```
1) 上电等 ≥1ms
2) 读 CHIP_ID(0x00)==0x24
3) 软复位 CMD(0x7E)=0xB6，等 2ms
4) 关 APS：PWR_CONF(0x7C) bit0=0        【关键】
5) INIT_CTRL(0x59)=0x00
6) INIT_DATA(0x5E) 灌 8KB 配置（突发写 ≤15 字节/次）
7) INIT_CTRL(0x59)=0x01，等 ≥150ms
8) 读 INTERNAL_STATUS(0x21) bit0==1，否则 init 失败
9) 恢复 APS（如需省电）
10) 使能陀螺  【关键：feature 引擎跑在陀螺时钟上】
```

## 5. FIFO + 中断（省电核心）

| 配置 | 建议值 |
|---|---|
| FIFO 模式 | Stream（满覆盖旧数据） |
| 内容 | header + accel + gyro，12 字节/帧 |
| Watermark | 20 帧（@200Hz → 每 100ms 醒一次） |
| INT1 映射 | FIFO watermark + significant motion |
| INT1 电气 | 推挽、低有效、锁存 5ms |

静止时主核零轮询，靠 INT1 唤醒——续航关键。

## 6. 跌倒检测算法（核心交付物）

### 物理前提

加速度计测**比力**而非运动加速度：静止读数 = 支撑力 = **1g = 9.8 m/s²**；自由落体支撑力消失 → 读数趋近 **0**。静止时 |a| 仍是 9.8——判"静止"看**方差小**，不是数值小。

### 四阶段状态机

| 阶段 | 条件 | 说明 |
|---|---|---|
| IDLE → FREEFALL | `|a| < 3.0` 连续 ≥5 帧（@200Hz≈25ms） | 失重 |
| FREEFALL → IMPACT | 500ms 内 `|a| > 25`（≈2.5g） | 触地冲击 |
| IMPACT → POSTURE | 1s 内 `Δθ > 45°` | 站立变躺倒 |
| POSTURE → STILL | 1.5s 窗口内 `std(|a|) < 0.5` | 倒地不起 → 判跌倒 |
| 任意 | 超时/条件不满足 → 回 IDLE | 自动复位 |

### 姿态角（唯一必须用陀螺的环节）

```
加速度静态倾角: pitch = atan2(ay, √(ax²+az²));  roll = atan2(-ax, √(ay²+az²))
陀螺积分:      θ += ω·dt   （动态好但漂移）
互补滤波:      θ = α(θ + ω·dt) + (1−α)·θ_acc,  α ≈ 0.98   （高频信陀螺、低频信加速度计）
判定:          Δθ = |θ_now − θ_before_fall| > 45°
```

### 防误报闸门

- **佩戴检测**：表不在手上不报警（避免放桌上被碰掉误报）。
- **二次确认**：STILL 后延迟 10s 再上报，期间抬腕活动即取消。
- **进阶**：用 BECO NPU 跑端侧 fall/non-fall 分类模型（2s 六轴窗口），替代纯阈值——作品差异化亮点。

### 已知代码缺陷（必须修）

`Silver-haired_Protector_LVGL/src/app/utils/health_rules.c` 的 `fall_detector_feed()` **Stage 2 用「最后 5 帧平均模值 > 20」判定**——真实跌倒后人躺平静止，模值回到 9.8 附近，该条件真机永不成立，只在 mock 的 burst 段能过。**必须用上述四阶段状态机替换**，同时：
- `constants.h`：`ACCEL_BUF_SIZE` 50→100（0.5s 窗口），加四阶段阈值宏
- 采样结构加陀螺 `gx/gy/gz`（rad/s）
- `sensor_service.c` 真实分支接 uORB

### 单位约定（务必对齐）

| 物理量 | BMI270 原始 | uORB 输出 | 算法输入 |
|---|---|---|---|
| 加速度 | LSB（±16g → 2048 LSB/g） | **m/s²** | m/s² |
| 角速度 | LSB（±2000°/s → 16.384 LSB/°/s） | **rad/s**（个别版本是 °/s，先打印一帧确认） | rad/s |
| 时间戳 | — | µs | ms |

## 7. 验证与标定

点亮验证（Bring-up）：

| 步骤 | 命令/方法 | 期望 |
|---|---|---|
| I2C 扫描 | `i2c scan -b <bus>` | 0x68 或 0x69 |
| CHIP_ID | 读寄存器 0x00 | 0x24 |
| 配置上传 | 读 INTERNAL_STATUS(0x21) bit0 | =1 |
| uORB 节点 | `ls /dev/uorb/` | sensor_accel0 / sensor_gyro0 |
| 出数 | `uorb_listener sensor_accel` 或 `sensortest -n 1 accel` | 稳定出数，速率=ODR |
| 静态自检 | 表盘朝上静置 | ax≈0, ay≈0, az≈±9.8 |

标定（必做，不做倾角误差 5~10°）：六面法求零偏 offset 与标度，写入 storage 持久化；贴片有角度偏差时求 3×3 旋转矩阵补偿。

算法验证：200Hz 六轴数据落盘 CSV → 场景库（正例：前/后/侧倒、椅子滑落、踏空；反例：蹲下、拍桌、甩手、坐下、跑步、摘表扔桌，各 20 次多人）→ Python 离线回放学阈值 → 目标**召回 ≥95%、误报 ≤1 次/天** → 5 名志愿者真人试戴 1 周。
