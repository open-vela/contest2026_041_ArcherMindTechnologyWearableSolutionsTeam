# OpenVela 应用开发与编译参考

涵盖开发环境、源码树放置、Kconfig/Makefile、LVGL 应用结构与平台限制。参考工程：`Silver-haired_Protector_LVGL`（33 个 C 文件）+ `openvela-build/`（11 个构建文件）+ `OPENVELA_BUILD_GUIDE.md`。

## 1. 开发环境

- **协同模式**：Windows 主机（编辑/烧录）+ Linux VM（编译）。实战 VM：主机名 `yuhuan-virtual-machine`，用户 yuhuan/root，工作目录 `/opt/openvela_2026`。
- **源码**：经 github.com/open-vela/ 同步（AOSP-like 仓，repo 管理）。
- **构建体系**：NuttX 内核 + Flat Build + Kconfig/Makefile。
- **构建命令**：`build.sh vendor/openvela/boards/vela/configs/<board>/<config>`；QEMU 目标用 `goldfish-armeabi-v7a-ap`。
- 另：Windows 上可用 OpenSiFli SDK v2.5（SCons + MSVC）调 PCSIM 模拟器（SiFli SF32LB52 方向，非 BES）。

## 2. 应用放进源码树的位置与三件套

LVGL 应用放 `apps/` 下（或 vendor 指定应用目录），每个应用需要三件套：

```
apps/<your_app>/
├── Kconfig      # config APP_YOUR_APP (bool, default n)，在 apps/Kconfig 里 source
├── Make.defs    # ifeq ($(CONFIG_APP_YOUR_APP),y) CONFIGURED_APPS += $(APPDIR)/<your_app>
└── Makefile     # PROGNAME/MAINSRC/CSRCS，include $(APPDIR)/Application.mk
```

移植步骤（高层）：
1. 拷贝应用源码到 `apps/<your_app>/`；
2. 写三件套并在父级 Kconfig 中 source；
3. `menuconfig` 勾选应用 + LVGL + 传感器驱动（BMI270 见 bmi270-integration.md）；
4. 板级 config 里注册 LVGL 显示/输入端口（port 驱动放应用目录或 board 目录）；
5. `build.sh` 全量构建，QEMU 先跑通再上 EVB。

## 3. 参考工程结构（Silver-haired_Protector_LVGL）

```
src/app/
├── app/        # 入口、生命周期、页面路由
├── theme/      # LVGL 主题（配色/字体，老年友好大字号）
├── ui/         # 页面：index(登录)/home(8 项运动)/sport(3 卡片竖滑)/test(训练)/result/settings
├── services/   # sensor_service / health_service / alarm_service / mqtt_service / http_service
└── utils/      # health_rules(跌倒/体征判定) / constants.h / storage 持久化
```

- **LVGL 版本**：v9。
- **designWidth 480**（手表分辨率基准）。
- 页面逻辑与快应用版 `Silver-haired_Protector` 保持一致（功能对照移植）。

## 4. OpenVela 快应用 CSS 限制（移植到 LVGL/写样式时同样适用）

**禁用的 CSS 属性**（快应用引擎不支持，LVGL 移植时用 LVGL 原生布局替代）：
- `flex: 1`（用固定尺寸或 LVGL flex grow 参数替代）
- `position: absolute / relative`
- `align-self`
- `border: none` 及 `border` 简写（须拆成 border-width/style/color 分项）

## 5. 数据采集与上传链路

| 环节 | 方案 | 备注 |
|---|---|---|
| 心率/运动数据 | `service.health` API 的 `subscribeSample` 接口（快应用）/ uORB（LVGL C 版） | |
| 实时上传 | **MQTT** | |
| 备份上传 | **HTTP** | 双模互补 |
| 本地持久化 | `storage` | 断网缓存后补传 |
| WebSocket | **不可用** — OpenVela 模拟器不支持原生 WebSocket，这是选 MQTT+HTTP 双模的原因 | |

## 6. 后端对接约定

- Go 微服务：device / vital / alarm / user-service，Docker Compose 部署 + Nginx 网关。
- 设备 SN `EH-WATCH-20260101` ↔ elderly_id `47e306a7-76b0-11f1-a296-0242ac130012`。
- 报警链路：手表判定跌倒/体征异常 → MQTT 上报 → alarm-service → 通知家属/平台。

## 7. 编译常见问题

- 新增源文件未加进 Makefile `CSRCS` → 链接报 undefined symbol。
- Kconfig 未在父级 source → menuconfig 里找不到应用项。
- LVGL 版本 API 差异（v8 vs v9 大量函数改名）→ 以源码树里 `lvgl/lvgl.h` 为准。
- QEMU 跑通 ≠ 真机跑通：真机有 IOMUX、电平、传感器初始化时序问题，分阶段验证（先 QEMU 逻辑，再 EVB 硬件）。
