# BES2800BP EVB 硬件参考（ZE7/JE6 V1.2 / ZE V1.3）

适用于开发板接线、供电、选引脚、上拉电阻等任务。信息来自 EVB 使用说明（V1.2 PPT）、User Guide v0.40 与实物验证。

## 1. 开发板区域

| 区域 | 说明 |
|---|---|
| 供电区域 | VSYS 经板上 DC-DC/LDO 转换为 3.3V / 2.8V / 1.8V；VSYS 输入范围 **3.6V ~ 5.5V** |
| 按键区 | 从左到右 **POWER** / **RESET**，芯片低电平开机 |
| 屏幕接口 | 屏幕供电 + 通信接口，支持 MIPI / SPI |
| USB 接口 | 与芯片 USB 连接，传输数据 |
| USB2 Uart 接口 | 板载串口芯片，可下载/调试，对应 **GPIO22-23**，电平 **1.8V** |
| SPK 接口 | SPK 差分输出 |
| EMMC | 供电 3.3V/1.8V，4 线/8 线，容量 4G |
| MIC | 模拟/数字 MIC，输出 1.5~3V，载流 <10mA |

## 2. 板载功能

| 功能 | 规格 |
|---|---|
| 屏幕 | RM69330 DSI |
| 触摸 | TMA525 |
| 存储 | 4G EMMC + 16MB NOR Flash + 4M NOR Flash |
| 内存 | 64M PSRAM |
| WiFi | 内置 |
| 下载口 | USB 转串口（Type-C，排针左侧） |

## 3. 关键点位（必记）

| 点位 | 功能 |
|---|---|
| `P54 / P55` | **UART1 — Log 输出 / Vela 控制台**（电平 1.8V） |
| 排针左侧 Type-C 口 | **下载口**（USB2 Uart） |
| `GPIO22 (G22)` | UART0 RX — 固件下载用，**勿挪作他用** |
| `GPIO23 (G23)` | UART0 TX — 固件下载用，**勿挪作他用** |
| VSYS 供电插针（左上角） | 输出 3.3V / 2.8V / 1.8V，外接模块取电处 |

**丝印规则：`Gxx = GPIOx`，`Pxx = PMUx`。** 排针不印 I2C/SPI 功能名，因为外设走 IOMUX 复用。

## 4. 供电方式（二选一）

| 方式 | 操作 |
|---|---|
| A：外部电源 | VSYS 接 **3.8V**（范围 3.6~5.5V），GND 接地，按 POWER 开机 |
| B：USB 供电 | 短接 **USB2 Uart → VSYS** 跳帽，经 USB 转串口给 VSYS 供电 |

外接传感器模块（如 BMI270）的 3.3V 取自 **VSYS 插针组的 3.3V 脚**；丝印看不清就通电用万用表量：黑表笔接 GND，红表笔逐脚碰，读数 ≈3.3V 的脚即是。

## 5. IOMUX 与引脚选择

**BES2800BP 的 I2C/SPI/UART 均无固定物理引脚**，由 IOMUX 把功能映射到任意 GPIO。选引脚方法（按优先级）：

1. **查源码**（最权威）：
   ```bash
   grep -rn "HAL_IOMUX_FUNC_I2C_M" platform/hal/hal_iomux*.h
   grep -rn "I2C0_SCL\|I2C0_SDA\|CFG_HW_I2C" target/<板型>/tgt_hardware.h
   grep -rn "GPIO_I2C" vendor/<vendor>/boards/<board>/include/board.h
   ```
2. **看丝印**：只能确认 G 脚编号，无法得知功能（本板无 I2C 丝印）。
3. **实测**：I2C 空闲应为高电平；断电测对地阻值，I2C 脚常有上拉（几百 Ω~几 kΩ）。

IOMUX 配置示例（BES SDK 风格）：

```c
static const struct HAL_IOMUX_PIN_FUNCTION_MAP i2c1_pinmux[] = {
    { GPIO_36, HAL_IOMUX_FUNC_I2C_M1_SCL,
      HAL_IOMUX_PIN_VOLTAGE_VIO, HAL_IOMUX_PIN_PULLUP_ENABLE },
    { GPIO_37, HAL_IOMUX_FUNC_I2C_M1_SDA,
      HAL_IOMUX_PIN_VOLTAGE_VIO, HAL_IOMUX_PIN_PULLUP_ENABLE },
};
```

实战用过的接法（BMI270）：`SCL→G36(I2C1_SCL)`、`SDA→G37(I2C1_SDA)`、`INT1→G40(中断)`。引脚可换任意相邻 GPIO 对，**但软件 IOMUX、I2C 总线号、从机地址三处必须同步对齐**。

## 6. 上拉电阻操作（i2c scan 扫不到时的手段之一）

I2C 为开漏输出，SCL/SDA 必须各有上拉才能出高电平。**先排查再加电阻**——扫不到的概率排序：CSB 未上拉 > 接线/IOMUX 错 > 地址错 > 上拉缺失。

加之前确认两件事：
1. **模块是否已自带上拉**：断电测 `SCL↔3.3V`、`SDA↔3.3V` 阻值，几 KΩ 则已有，别再并（并联越并越小，<1KΩ 芯片拉不动）。
2. **目标引脚的 IO 电平域**：上拉必须拉到与主控 IO 相同的电平。板上部分 IO 是 1.8V 域（UART 即 1.8V），把 1.8V 域引脚上拉到 3.3V 有烧 IO 风险。

三种方式（按推荐序）：

| 方式 | 做法 | 说明 |
|---|---|---|
| 软件内部上拉 | IOMUX 配置 `HAL_IOMUX_PIN_PULLUP_ENABLE` | 零成本先验证；内部上拉 30~50KΩ 偏弱，100kHz 可、400kHz 波形差，量产仍需外部电阻 |
| 杜邦线飞线 | 4.7KΩ 电阻一端接 3.3V 排针，另一端接 SCL/SDA 公共节点，各一颗 | 最快外部验证 |
| 焊接 | 洞洞板/排针座焊死 | 验证通过后固定 |

阻值选择：2.2KΩ（线长/400kHz/多设备）~ 10KΩ（省电/100kHz/短线），**默认 4.7KΩ**。

验证：断电测阻值 ≈4.7K（模块自带上拉则并联值偏小，正常）；上电空闲 SCL/SDA 均应为高电平；再跑 `i2c scan`。

**易犯错误**：上拉接到 5V/VSYS（烧 IO）；模块自带+内部+外部三重并联；不排查就直接加电阻。

## 7. 电平警告汇总

- UART0（G22/23 下载口）、UART1（P54/P55 Log 口）：**1.8V**，禁用 3.3V/5V 调试器。
- BMI270 模块 6 针版 VDD 与 VDDIO 在模块内连在一起（3.3V），若主控 IO 为 1.8V 域需电平转换或选 3.3V 域引脚。
