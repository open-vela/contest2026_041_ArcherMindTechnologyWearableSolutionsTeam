---
name: openvela-bes-dev
description: 在 OpenVela（NuttX 内核）与恒玄 BES2800BP 芯片上开发智能手表健康监测系统（AI 老年健康守护系统）的端到端指南。This skill should be used when: 在 open-vela 源码中新增/移植 LVGL 应用、在 BES2800BP EVB（ZE7/JE6 V1.2/V1.3）上接线调试传感器（BMI270 六轴）、配置 IOMUX/I2C、实现跌倒检测算法、用 dldtool 烧录固件、处理 NuttX Kconfig/board 注册/uORB 传感器接入、或排查烧录与串口通信问题。触发关键词：openvela、OpenVela、BES2800、恒玄、BES、BMI270、跌倒检测、LVGL 移植、uORB、dldtool 烧录、NuttX Kconfig。
agent_created: true
---

# OpenVela + 恒玄 BES2800BP 手表健康系统开发指南

## Overview

在 OpenVela（NuttX fork）与恒玄 BES2800BP 平台上开发智能手表健康监测系统的全流程：LVGL 应用开发 → BMI270 传感器接入 → OpenVela 编译 → EVB 烧录测试。参考实现为「AI 老年健康守护系统」（`Silver-haired_Protector_LVGL`）。本指南沉淀了该项目多轮实战验证的硬件点位、驱动坑点、算法参数与烧录命令，优先于通用知识使用。

## 使用前必读：四条高压线

1. **UART 电平 1.8V** — EVB 的 UART0（G22/G23，固件下载口）和 UART1（P54/P55，Log/控制台口）通信电平均为 **1.8V**。接 3.3V 或 5V 串口调试器会损坏 GPIO。
2. **BMI270 的 CSB 必须上拉到 VDDIO** — 否则上电采样到低电平进入 SPI 模式，I2C 永远扫不到设备。6 针转接模块若无 CSB 引脚，需确认模块内部已上拉。
3. **BMI270 必须上传 8KB 配置文件，且陀螺必须使能** — 不上传配置则高级功能（计步/活动识别）全失效；陀螺不使能则内部 feature 引擎没有工作时钟，同样静默失效。
4. **I2C 没有固定物理引脚** — BES2800BP 的 I2C 走 IOMUX 复用，任意 GPIO 都可配成 I2C。EVB 丝印 `Gxx=GPIOx`、`Pxx=PMUx`；**G22/G23 已被 USB-UART0 占用，必须避开**。

## 工作流决策树

按当前任务阶段，加载对应的 references 文件获取完整细节：

| 当前任务 | 加载文件 |
|---|---|
| 开发板认识、供电、选引脚、接线、加上拉电阻 | `references/hardware-evb.md` |
| BMI270 接线、地址确认、驱动注册、上电初始化、跌倒检测算法、标定 | `references/bmi270-integration.md` |
| LVGL 应用移植、OpenVela 源码放置、Kconfig/Makefile、编译、平台 CSS 限制 | `references/openvela-build.md` |
| 固件编译产物、SCP 传输、dldtool 烧录、脚本速查、串口测试 | `references/flash-test.md` |

## 阶段一：硬件准备与接线（→ hardware-evb.md）

- 识别 EVB 区域：VSYS 供电插针（输出 3.3V/2.8V/1.8V）、POWER/RESET 按键（低电平开机）、排针左侧 Type-C 下载口（USB2 Uart）、P54/P55 Log 口。
- 供电二选一：VSYS 接 3.8V（范围 3.6~5.5V）外部电源；或短接 USB2 Uart→VSYS 跳帽用 USB 供电。
- 给传感器选 I2C 引脚时避开 G22/G23，挑相邻 GPIO 对（如 G36/G37 配 I2C1，G40 配中断），软件 IOMUX 同步配置。
- `i2c scan` 扫不到设备时按概率排查：CSB 未上拉 > 接线/IOMUX 配错 > 地址不对 > 上拉电阻缺失（4.7KΩ 上拉到与 IO 域一致的电压）。

## 阶段二：BMI270 传感器接入（→ bmi270-integration.md）

- 优先 I2C 400 kHz（200 Hz 六轴仅 2.4 KB/s）；NuttX 主线已有驱动 `drivers/sensors/bmi270_base.c` + `bmi270_uorb.c`，开 `CONFIG_SENSORS_BMI270_UORB/I2C` 即可，不必自研驱动。
- 工作量在算法不在驱动：跌倒检测用四阶段状态机「失重(|a|<3) → 冲击(|a|>25) → 姿态变化(Δθ>45°) → 静止(σ<0.5)」，姿态角用互补滤波（α≈0.98）融合加速度与陀螺。
- **已知缺陷**：参考工程 `health_rules.c` 的 `fall_detector_feed()` Stage 2 用「平均模值>20」判定，真实跌倒后人躺平静止模值回到 9.8，真机必漏报——必须用四阶段状态机替代。

## 阶段三：OpenVela 应用开发与编译（→ openvela-build.md）

- 开发环境：Windows 主机 + Linux VM 协同，VM 工作目录 `/opt/openvela_2026`，源码经 github.com/open-vela/ 同步；`build.sh vendor/openvela/boards/vela/configs/<config>` 构建。
- 应用放源码树内用 Kconfig/Make.defs/Makefile 三件套注册；LVGL v9，目标 designWidth 480。
- 遵守 OpenVela CSS 限制：**禁用 flex:1、position:absolute/relative、align-self、border:none 及 border 简写**。
- 数据上传用 MQTT 实时 + HTTP 备份双模（OpenVela 模拟器不支持原生 WebSocket）。

## 阶段四：烧录与测试（→ flash-test.md）

- 编译脚本 `1700_ap.sh`，产物在 `cmake_out/aos_evb_ap/` 等目录，SCP 传到 Windows 的 `D:\BES2800BP\program\`。
- 首次用 `updateall.bat` 全量烧录 7 个固件；日常开发只刷 AP（`ap_update.bat`）。
- 烧录时序：命令显示 `Wait for SYNC started` 后再按 RESET；`PROGRAMMING SUCCEEDED` 即成功。
- 脚本里的 COM 口号（3/21/41/74）和服务器 IP 都是硬编码，使用前必须按实际环境修改。

## 项目背景约定

- **参考工程**：`Silver-haired_Protector_LVGL`（LVGL C 应用），结构 `src/app/{app,theme,ui,services,utils}`；快应用版 `Silver-haired_Protector` 页面为 index（登录）/home（8 项运动列表）/sport（3 卡片竖滑）/test（训练）/result/settings。
- **后端**：Go 微服务（device/vital/alarm/user-service），Docker Compose 部署 + Nginx 网关；设备 SN `EH-WATCH-20260101` 对应 elderly_id `47e306a7-76b0-11f1-a296-0242ac130012`。
- **完整方案文档**（若在当前工作区可用，优先读取）：`BMI270_BES2800BP_接入方案.md`（10 章完整实施方案）、`D:\BES2800BP\BES2800BP_代码下载烧录测试指南.md`（烧录全细节）。
- **差异化方向**：BES2800BP 双核 BECO NPU 可用于端侧跌倒分类模型，替代/增强纯阈值方案——这是作品的核心技术亮点。
